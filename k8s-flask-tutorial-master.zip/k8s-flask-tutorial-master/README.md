# Flask on Kubernetes

Read the deployment guide: [A Guide to Deploy Flask App on Google Kubernetes Engine](https://medium.com/@pyk/a-guide-to-deploy-flask-app-on-google-kubernetes-engine-bfbbee5c6fb)
